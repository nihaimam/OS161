// Prints Hello World!

hello()
{
	kprintf("Hello World!\n");
}
