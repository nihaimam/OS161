#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <kern/callno.h>
#include <syscall.h>
#include <curthread.h>
#include <addrspace.h>
#include <thread.h>
#include <synch.h>
#include <vnode.h>
#include <uio.h>
#include "opt-synchprobs.h"
#include <kern/unistd.h>
#include <vfs.h>
#include <machine/spl.h>
#include <kern/limits.h>
#include <test.h>
#include <vm.h>
#include <process_create.h>

/*
void sys__exit(int code);
int sys_getpid(int *ret);
int sys_execv(char *program, char **args);
pid_t sys_fork(struct trapframe* tf, pid_t *ret);
pid_t sys_waitpid(pid_t pid, int *status, int options);
*/

void md_forkentry(struct trapframe *tf, unsigned long as_data){
	struct trapframe tf_local;
	struct trapframe* childtf;
	struct addrspace* child_addr = (struct addrspace*) as_data;
	tf_local = *tf;
	childtf = &tf_local;
	childtf->tf_v0 = 0;
	childtf->tf_a3 = 0;
	childtf->tf_epc += 4;
	curthread->t_vmspace = child_addr;
	as_activate(curthread->t_vmspace);
	mips_usermode(&tf_local);
}

int sys_fork(struct trapframe* tf, int* retval){
	struct thread* newthread;
	struct trapframe* childtf;
	struct addrspace* child_addr;
	int result;
	if(curthread-> pid >= MAXPID){
		return EAGAIN;
	}
	childtf = (struct trapframe*) kmalloc(sizeof(struct trapframe));
	if (childtf == NULL){
		kfree(childtf);
		return ENOMEM;
	}
	*childtf = *tf;
	int ret = as_copy(curthread->t_vmspace, &child_addr);
	if (child_addr == NULL){
		kfree(childtf);
		return ENOMEM;
	}
	if (ret != 0){
		kfree(childtf);
		return ENOMEM;
	}
	as_activate(curthread->t_vmspace);
	result = thread_fork(curthread->t_name, childtf,(unsigned long)child_addr,
			    (void (*)(void *, unsigned long)) md_forkentry,&newthread);
	if (result){
		kfree(childtf);
                return ENOMEM;
	}
	*retval = (int) newthread->pid;
	return 0;
}

int sys_getpid (void){
	return (int)curthread->pid;
}

void sys__exit (int exitcode){
	struct process* ptr = curthread->array_ptr;
	ptr->status = PROCESS_STOP;
	ptr->exitcode = exitcode;
	lock_acquire(process_lock);
	struct process* curr = curthread->array_ptr;
	cv_signal(curr->array_cv, process_lock);
	thread_exit();
}

int sys_execv(char *program, char **args){
	struct vnode *v;
	int result, argc, spl;
	int *length;
	size_t buflen;
	int i = 0;
	spl=splhigh();
	vaddr_t entrypoint, stackptr;
	char *progname = (char*)kmalloc(PATH_MAX);
	copyinstr((userptr_t)program,progname,PATH_MAX,&buflen);
	char **argv= (char **)kmalloc(sizeof(char*));
	if (progname == NULL){
		return ENOMEM;
	}
	while (args[i] != NULL){
		i++;
	}
	argc = i;
	if (argv == NULL){
		kfree(progname);
		return ENOMEM;
	}
	for (i = 0; i < argc; i++){
		length[i] = strlen(args[i]);
		length[i] = length[i] + 1;
	}
	for (i=0; i<=argc; i++){
		if (i < argc){
			argv[i] = (char*)kmalloc(length[i]+1);
			if(argv[i]==NULL){
				return ENOMEM;
			}
			copyinstr((userptr_t)args[i], argv[i], length[i], &buflen);
		}
		else {
			argv[i] = NULL;
		}
	}
	int arglength[argc];
	int arg_pointer[argc];
	int offset = 0;
	int count;
	for (count = argc-1; count >= 0; count--){
		arglength[count] = strlen(argv[count])+1;
	}
	/* Open the file. */
	result = vfs_open(progname, O_RDONLY, &v);
	if (result){
		return result;
	}
	if (curthread->t_vmspace){
		struct addrspace *as = curthread->t_vmspace;
		curthread->t_vmspace = NULL;
		as_destroy(as);
	}
	/* We should be a new thread. */
	assert(curthread->t_vmspace == NULL);
	/* Create a new address space. */
	curthread->t_vmspace = as_create();
	if (curthread->t_vmspace==NULL){
		vfs_close(v);
		return ENOMEM;
	}
	/* Activate it. */
	as_activate(curthread->t_vmspace);
	/* Create a new address space. */
	curthread->t_vmspace = as_create();
	if (curthread->t_vmspace==NULL){
		vfs_close(v);
		return ENOMEM;
	}
	/* Activate it. */
	as_activate(curthread->t_vmspace);
	/* Load the executable. */
	result = load_elf(v, &entrypoint);
	if (result){
		vfs_close(v);
		return result;
	}
	/* Done with the file now. */
	vfs_close(v);
	/* Define the user stack in the address space */
	result = as_define_stack(curthread->t_vmspace, &stackptr);
	if (result){
		return result;
	}
	for (i = argc-1; i >= 0; i--){
		offset = (arglength[i] + (4-(arglength[i]%4)));
		stackptr = stackptr - offset;
		copyoutstr(argv[i], (userptr_t)stackptr, (size_t)arglength[i], &buflen);
		arg_pointer[i] = stackptr;
	}
	arg_pointer[argc] = (int)NULL;
	i = argc;
	while (i >= 0){
		stackptr = stackptr - 4;
		copyout(&arg_pointer[i] ,(userptr_t)stackptr, sizeof(arg_pointer[i]));
		i--;
	}
	kfree(argv);
	kfree(progname);
	splx(spl);
	md_usermode(argc , (userptr_t)stackptr, stackptr, entrypoint);
	panic("md_usermode returned\n");
	return EINVAL;
}

int sys_waitpid (pid_t pid, int* status, int options, int* retval){
	if (options != 0){ 
		return EINVAL;
	}
	if (status == NULL){
		return EFAULT;
	}
	struct process *child = NULL;
	child = get_process(pid);
	if (child == NULL){
		return EFAULT;
	}
	lock_acquire(process_lock);
	if (child->ppid != curthread->pid){
		lock_release(process_lock);
		return EINVAL;
	}
	if (child->ppid == curthread->pid){
		if (child->status == PROCESS_STOP){
			*status = child->exitcode;
			lock_release(process_lock);
		}
		else {
			cv_wait(child->array_cv,process_lock);
			*status = child->exitcode;
			lock_release(process_lock);
		}
	}
	lock_release(process_lock);
	*retval = (int) child->pid;
	return 0;
}










