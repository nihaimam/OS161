#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <kern/callno.h>
#include <syscall.h>
#include <curthread.h>
#include <addrspace.h>
#include <thread.h>
#include <synch.h>
#include <vfs.h>
#include <machine/spl.h>
#include <kern/limits.h>
#include <test.h>
#include <vm.h>
#include <types.h>

#include <kern/unistd.h>
#include <kern/errno.h>
#include <array.h>
#include <scheduler.h>
#include <vnode.h>
#include "opt-synchprobs.h"



#define MAX_ARGS_NUM 256


struct cv *cv_parent_queue = cv_create("parent_queue");
struct lock *lock_thread_join;
struct lock *lock_exit = lock_create("lock_exit");

/*
 * sys_getpid
 * 
 * simplest one
 * return the pid of the executing process
 * getpid does not fail
 */
int getpid (int *retval){
	*retval = (int)curthread->pid;
	//since getpid doesnt fail
	return 0;
}


/*
 * sys_fork
 *
 * duplicate the current process
 * in case of an error return -1
 */
pid_t sys_fork(struct trapframe *tf, pid_t *ret){
	pid_t child_pid;
	int result;
	//Allocate heap
	struct trapframe *child_tf = kmalloc(sizeof(struct trapframe));
	//Copy parent trapframe to the to-be child copy
	memcpy(child_tf, tf, sizeof(struct trapframe));
	//Create a new address space
	struct addrspace *child_addrspace;
	//Copy using as_copy
	as_copy(curthread->t_vmspace, &child_addrspace);
	struct thread *child_thread;
	
	result = thread_fork(curthread->t_name, (void*)child_tf, (unsigned long)child_addrspace, md_forkentry, &child_thread);
	if (result != 0){
		return result;
	}
	else { //thread_fork returns to PARENT w/ the PID of the child
		*ret = child_thread->pid;
	}
	return 0;
}


/*
 * md_forkentry
 *
 * create new child trapframe by copying parent’s
 * get the assigned child pid from parent’s trapframe tf_v0
 * assign it to the pid of the current process
 * set the trapframe’s tf_v0 to 0
 * increment tf_epc by 4
 * copy the passed address space to the current process address space
 * activate it
 * give the control back
 */
void md_forkentry (struct trapframe *tf, unsigned long addr){
	//copy the trapframe by simply declaring a struct and copying tf there
	struct trapframe *cpy_tf = (struct trapframe *)tf;
	//make sure the child thread returns to usermode
	//ensuring we set the v0 and a0 registers to 0
	//incrementing the PC counter by 4 to show we successfully finished
	(cpy_tf)->tf_v0 = 0;
	(cpy_tf)->tf_a3 = 0;
	(cpy_tf)->tf_epc += 4;
	struct trapframe stk_tf;
	memcpy(&stk_tf, cpy_tf, sizeof(struct trapframe));
	cpy_tf = &stk_tf;
	//take the copy of the address space of the parent
	//and copy it to the child's
	curthread->t_vmspace = (struct addrspace *)addr;
	as_activate(curthread->t_vmspace);
	mips_usermode(cpy_tf); 
}


/*
 * sys_execv
 *
 * replace the currently executing program image with a new process image
 * process id is unchanged
 * check the last argument in **args is NULL
 * make sure it is less than MAX_ARGS_NUM
 * copyin the arguments from user space to kernel space
 * create a new address space, allocate a stack on it
 * copyout the arguments back onto the new stack
 */
int sys_execv(char *progname, char **args){
	struct vnode *v;
	vaddr_t stackptr, entrypoint;
	int result;
    	int string_size = 0; //s_size	
	int kargc = 0;
	int err;
	char ** kernel_args;
	size_t check;
	
	if (args == NULL) return EFAULT;
	if (progname == NULL) return ENOEXEC;
	
	struct addrspace* temp =(struct addrspace*)kmalloc(sizeof(struct addrspace));
	if (temp == NULL) return ENOMEM;
	while (args[kargc] != NULL){
		kargc++;
	}
	err = as_copy(curthread->t_vmspace, &(temp));
	if (err){
		kfree(temp);
		return ENOMEM;
	}
	kernel_args = (char **)kmalloc((kargc)*sizeof(char*));
	if (kernel_args == NULL){
		free(kernel_args);
		return ENOMEM;
	}
	
	int i,j;
	for (i = 0; i<kargc; i++){
		string_size = strlen(args[i]);
		kernel_args[i] =(char *)kmalloc(string_size * sizeof(char));
		if (kernel_args[i]== NULL){
			kfree(temp);
			for(j =0; j<i; j++){
				kfree(kernel_args[j]);
			}
			kfree(kernel_args);
			return ENOMEM;
		}
		err = copyinstr(args[i], kernel_args[i], string_size+1, &check);
		if (err){
			for(i = 0; i<kargc; i++){
				kfree(kernel_args[i]);
			}
			kfree(temp);
			kfree(kernel_args);
			return err;
		}
	}
	kernel_args[kargc] = NULL;
	
	// now follow the same procedure as run program
	
//-------
/* Open the file. */
    result = vfs_open(progname, O_RDONLY, &v);
    if (result) {
	 kfree(temp);
	for(i = 0; i<kargc; i++)
	    kfree(kernel_args[i]);
		kfree(kernel_args);
	return result;
    }
//Destroy the old address space, and setup the new one
as_destroy(curthread->t_vmspace);
    curthread->t_vmspace = NULL;

    //Setup new vmspace.
    curthread->t_vmspace = as_create();
	
    if (curthread->t_vmspace==NULL) {
	curthread->t_vmspace = temp;
	
	for(i = 0; i<kargc; i++)
	    kfree(kernel_args[i]);
		kfree(kernel_args);
		vfs_close(v);
		return ENOMEM;
    }

    /* Activate vmspace */
    as_activate(curthread->t_vmspace);

    /* Load the executable. */
    result = load_elf(v, &entrypoint);
    if (result) {
	as_destroy(curthread->t_vmspace);
	curthread->t_vmspace = temp;
	
	 
	for(i = 0; i<kargc; i++)
	    kfree(kernel_args[i]);
	kfree(kernel_args);
	vfs_close(v);
	return result;
    }

    /* Done with the file now. */
    vfs_close(v);

//------
	//We now prepare the user stack by placing the arguments on it, like we did in runprogra
	result = as_define_stack(curthread->t_vmspace, &stackptr);
	//if error
	//--------
	if (result) {
	as_destroy(curthread->t_vmspace);
	curthread->t_vmspace = temp;

	for(i = 0; i<kargc; i++)
	    kfree(kernel_args[i]);
		kfree(kernel_args);
	return result;
    }
//new addr space user stack
vaddr_t new_args[kargc];
    int padding; 
     
    /*place all the strings on the stack*/
    
    for(i = (kargc-1); i>=0 ; i--){
	string_size = strlen(kernel_args[i]);
	padding = ((string_size / 4 ) + 1)*4;
	
	stackptr = stackptr - padding;
//Do a copyout and check if success/fail
	err = copyoutstr(kernel_args[i], stackptr, string_size+1, &check);
		if(err){
			return err;
		}
	
		//Success!
		new_args[i] = stackptr;
    }

  
    new_args[kargc] = NULL;
    for(i = kargc-1; i>=0 ; i--){
	stackptr= stackptr- 4;
	err = copyout(&(new_args[i]), stackptr, 4);
		if(err){
			return err;
		}
   }
    for(i =0; i<kargc; i++){
		kfree(kernel_args[i]);
	}
    kfree(temp);
	kfree(kernel_args);
        
    /* Warp to user mode. */
    md_usermode(kargc, stackptr, stackptr, entrypoint);
	
	//--------


	}

	/*struct vnode *v;
	int result, argc, spl;
	int *length;
	size_t buflen;
	int i = 0;
	int j = 0;
	int k = 0;
	spl = splhigh();
	vaddr_t entrypoint, stackptr;
	char *progname = (char*)kmalloc(PATH_MAX);
	copyinstr((userptr_t)program,progname,PATH_MAX,&buflen);
	char **argv= (char **)kmalloc(sizeof(char*));	
	if (progname == NULL){
		return ENOMEM;
	}
	while (args[i] != NULL){
		i++;
	}
	argc = i;
	if (argv == NULL){
		kfree(progname);
		return ENOMEM;
	}
	for (i = 0; i < argc; i++){
		length[i] = strlen(args[i]);
		length[i] = length[i] + 1;
	}
	for (i = 0; i <= argc; i++){
		if (i < argc){ 
			argv[i] = (char *)kmalloc(length[i] + 1);
			if (argv[i] == NULL){
				return ENOMEM;
			}
			copyinstr((userptr_t)args[i], argv[i], length[i], &buflen);
		}
		else {
			argv[i] == NULL;
		}
	}
	int arglength[argc];
	int arg_pointer[argc];
	int offset = 0;
	//pass arglength of argv
	int count;
	for(count = argc-1; count >= 0; count--){
		arglength[count] = strlen(argv[count]) + 1;
	}
	//open file
	result = vfs_open(progname, O_RDONLY, &v);
	if (result){
		return result;
	}
	if (curthread->t_vmspace){
		struct addrspace *as = curthread->t_vmspace;
		curthread->t_vmspace = NULL;
		as_destroy(as);
	}
	//new thread
	assert(curthread->t_vmspace == NULL);
	//new address space
	curthread->t_vmspace = as_create();
	if (curthread->t_vmspace == NULL){
		vfs_close(v);
		return ENOMEM;
	}
	//activate it
	as_activate(curthread->t_vmspace);
	//load the executable
	result = load_elf(v, &entrypoint);
	if (result){
		//thread_exit destroys curthread->t_vmspace
		vfs_close(v);
		return result;
	}
	//done with file
	vfs_close(v);
	//define the user stack in the address space
	result = as_define_stack(curthread->t_vmspace, &stackptr);
	if (result){
		//thread_exit destroys curthread->t_vmspace
		return result;
	}
	for(i = argc-1; i >= 0; i--){
		offset = (arglength[i] + (4-(arglength[i]%4)));
		stackptr = stackptr - offset;
		copyoutstr(argv[i], (userptr_t)stackptr, (size_t)arglength[i], &buflen);
		arg_pointer[i] = stackptr;
	}
	arg_pointer[argc] = (int)NULL;
	i = argc;
	while (i >= 0){
		stackptr = stackptr - 4;
		copyout(&arg_pointer[i] ,(userptr_t)stackptr, sizeof(arg_pointer[i]));
		i--;
	}
	kfree(argv);
	kfree(progname);
	//warp to user mode
	splx(spl);
	md_usermode(argc , (userptr_t)stackptr, stackptr, entrypoint);
	panic("md_usermode returned\n");
	return EINVAL;				
}*/
//---------------------------------------------------------------------


//---------------------------------------------------------------------


/*
 * sys_waitpid
 *
 * wait for the process with pid to exit
 * return its exit code via the integer pointer status
 * return the pid with status assigned to exit status on success
 * if error, return -1 and set the ret pointer to the error code
 */
pid_t sys_waitpid(pid_t pid, int *status, int options){
	





	/*struct process *proc;
	struct process *curproc;
	//error checking
	//status must point to userland
	if (status >= USERTOP){
		return (pid_t) -EFAULT;
	}
	//if no options selected
	if (options!=0){
		return (pid_t) -EINVAL;
	}
	proc = getprocess(pid);
	if (proc == NULL){
		return (pid_t) -EINVAL;
	}
	if (proc->exited){
		*status = proc->exitcode;
		return pid;
	}
	curproc = getcurprocess();
	//do the wait
	lock_acquire(proctable_lock);
	cv_wait(curproc->childexit, proctable_lock);
	lock_release(proctable_lock);
	//clean up child here
	*status = proc->exitcode;
	return pid;*/
}


/*
 * sys_exit
 *
 * causes the current process to terminate
 * the process id of the exiting process cannot be reused 
 * don't put the exited pid back to available pid pool blindly
 * code is the exitcode that will be given to other processes who are interested in it
 */
void sys__exit(int exitcode){
	lock_acquire(lock_exit);
	struct pid_node *temp12;
	temp12 = find_node(curthread->pid);
	temp12->exited=1;	
	temp12->exitcode=exitcode;
	if((cv_parent_queue->count)>0)
		cv_broadcast(cv_parent_queue,lock_exit);
	lock_release(lock_exit);
	thread_exit();


	//report exit status
	/*pid_t pid = curthread->pid;
	struct process *parent = NULL;
	struct process *p = get_process(pid);
	if (p != NULL){
		//acquire exit lock
		lock_acquire(p->exitlock);
		p->exited = 1;
		//(void)code
		p->exitcode = code;
		//sleep on the exitcode
		cv_broadcast(p->exitcv, p->exitlock);
		lock_release(p->exitlock);
	}
	thread_exit();
	panic("exit sys__exit");
	return 0;*/	
}









