#include <types.h>
#include <lib.h>
#include <kern/errno.h>
#include <kern/unistd.h>
#include <array.h>
#include <machine/spl.h>
#include <machine/pcb.h>
#include <thread.h>
#include <curthread.h>
#include <scheduler.h>
#include <addrspace.h>
#include <vnode.h>
#include "opt-synchprobs.h"
#include <synch.h>

struct process* get_process (pid_t pid) {
  if (pid > MAXPID || pid < MINPID) {
    return NULL;
  }
  int i;
  for(i = MINPID; i <= MAXPID; i++){
    if((pid_t)i == pid){
      if(array_table[i] == NULL){
        return NULL;
      }
      else{
        return array_table[i];
      }
    }
  }
  return NULL;
}

struct thread * init_process(struct thread *thread){
    if (process_lock == NULL) {
      process_lock = lock_create("process_lock");
      if (process_lock == NULL) {
        kfree(thread->t_name);
        kfree(thread);
        thread = NULL;
        return thread;
      }
    }
   
    struct process* temp = kmalloc(sizeof(struct process));
    if (temp == NULL) {
      kfree(thread->t_name);
      kfree(thread);
      thread = NULL;
      return thread;
      panic("thread_bootstrap: Out of memory\n");
    }
    temp->array_cv = cv_create("array_cv");
    if (temp->array_cv == NULL) {
      kfree(thread->t_name);
      kfree(thread);
      kfree(temp);
      thread = NULL;
      temp = NULL;
      return thread;
      panic("thread_bootstrap: create_cv failed\n");
    }
      temp->pid = MINPID;
      temp->ppid = MINPID-1;
      temp->status = PROCESS_RUNNING;
      temp->exitcode = 0;
      temp->process_ptr = thread;
      thread->array_ptr = temp;
      thread->pid = MINPID;
      array_table[temp->pid] = temp;
      return thread;
}


struct thread * child_process(struct thread *thread){
      struct process* temp = kmalloc(sizeof(struct process));
      if (temp == NULL) {
        kfree(thread->t_name);
        kfree(thread);
        thread = NULL;
        return thread;
      }
      temp->array_cv = cv_create("array_cv");
      if (temp->array_cv == NULL) {
        kfree(thread->t_name);
        kfree(thread);
        kfree(temp);
        thread = NULL;
        temp = NULL;
        return thread;
      }
      lock_acquire(process_lock);
      temp->pid = next_pid();
      if(temp->pid == -1){
        cv_destroy(temp->array_cv);
        kfree(thread->t_name);
        kfree(thread);
        kfree(temp);
        thread = NULL;
        temp = NULL;
        return thread;
      }
      temp->ppid = curthread->pid;
      temp->status = PROCESS_RUNNING;
      temp->exitcode = 0;
      temp->process_ptr = thread;
      thread->array_ptr = temp;
      thread->pid = temp->pid;
      array_table[temp->pid] = temp;
      lock_release(process_lock);
      return thread;
}

pid_t next_pid (void){
	if (array_table == NULL) return -1;
	int i;
	for (i = MINPID; i < MAXPID; i++){
		if (array_table[i] == NULL) return (pid_t)i;
	}
	return -1;
}
