#ifndef _PROCESS_CREATE_H_
#define _PROCESS_CREAT_H_

#include <types.h>
#include <lib.h>
#include <kern/errno.h>
#include <kern/unistd.h>
#include <array.h>
#include <machine/spl.h>
#include <machine/pcb.h>
#include <thread.h>
#include <curthread.h>
#include <scheduler.h>
#include <addrspace.h>
#include <vnode.h>
#include "opt-synchprobs.h"
#include <synch.h>

struct thread * child_process(struct thread *thread);
struct thread * init_process(struct thread *thread);

#endif /* _HEllO_H_ */
