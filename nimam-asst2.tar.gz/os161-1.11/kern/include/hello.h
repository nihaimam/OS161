#ifndef _HELLO_H_
#define _HELLO_H_

void hello(void);

#endif /* _HEllO_H_ */
